// +build appengine

package util

func BytesToString(b []byte) string {
	return string(b)
}
